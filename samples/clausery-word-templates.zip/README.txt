Clausery: free Word templates

87 templates, in a folder per category. Each is an ordinary .docx file.

Two ways to use them:
1. Open a file in Word and replace each {tag} with your own details. Sections such as {#has_deposit}...{/has_deposit} are optional: keep the text inside if it applies, and delete it if not. Text inside {^has_deposit}...{/has_deposit} is the opposite: keep it only if the option does not apply.
2. Or open the template's page below and click "Fill it in now". Clausery asks a few questions and builds the finished document in your browser. Nothing is uploaded.

These are general samples, not legal advice. Have them reviewed for your jurisdiction before use.

INVOICES, RECEIPTS AND MONEY
- Payment demand letter: https://getclausery.github.io/templates/payment-demand-letter.html
- Promissory note: https://getclausery.github.io/templates/promissory-note.html
- Payment reminder letter: https://getclausery.github.io/templates/payment-reminder-letter.html
- Loan agreement: https://getclausery.github.io/templates/loan-agreement.html
- Invoice: https://getclausery.github.io/templates/invoice.html
- Payment receipt: https://getclausery.github.io/templates/payment-receipt.html
- Gift letter for a mortgage: https://getclausery.github.io/templates/gift-letter.html
- Expense reimbursement form: https://getclausery.github.io/templates/expense-reimbursement-form.html
- Credit note: https://getclausery.github.io/templates/credit-note.html

BUSINESS AGREEMENTS
- Independent contractor agreement: https://getclausery.github.io/templates/independent-contractor-agreement.html
- Statement of work: https://getclausery.github.io/templates/statement-of-work.html
- Consulting agreement: https://getclausery.github.io/templates/consulting-agreement.html
- Service agreement: https://getclausery.github.io/templates/service-agreement.html
- Subcontractor agreement: https://getclausery.github.io/templates/subcontractor-agreement.html
- Memorandum of understanding (MOU): https://getclausery.github.io/templates/memorandum-of-understanding.html
- Letter of intent (business purchase): https://getclausery.github.io/templates/letter-of-intent.html
- Partnership agreement: https://getclausery.github.io/templates/partnership-agreement.html
- Sales commission agreement: https://getclausery.github.io/templates/sales-commission-agreement.html
- Price quote: https://getclausery.github.io/templates/quote.html
- Purchase order: https://getclausery.github.io/templates/purchase-order.html
- Equipment rental agreement: https://getclausery.github.io/templates/equipment-rental-agreement.html
- Meeting minutes: https://getclausery.github.io/templates/meeting-minutes.html
- Board resolution: https://getclausery.github.io/templates/board-resolution.html
- Consignment agreement: https://getclausery.github.io/templates/consignment-agreement.html

FREELANCE CONTRACTS
- Web design contract: https://getclausery.github.io/templates/web-design-contract.html
- Graphic design contract: https://getclausery.github.io/templates/graphic-design-contract.html
- Photography contract: https://getclausery.github.io/templates/photography-contract.html
- Social media management contract: https://getclausery.github.io/templates/social-media-management-contract.html
- Freelance writing contract: https://getclausery.github.io/templates/freelance-writing-contract.html
- Video production contract: https://getclausery.github.io/templates/video-production-contract.html
- Virtual assistant agreement: https://getclausery.github.io/templates/virtual-assistant-agreement.html
- Event planning contract: https://getclausery.github.io/templates/event-planning-contract.html
- Personal training agreement: https://getclausery.github.io/templates/personal-training-agreement.html
- Tutoring agreement: https://getclausery.github.io/templates/tutoring-agreement.html
- Retainer agreement: https://getclausery.github.io/templates/retainer-agreement.html
- Photo and model release: https://getclausery.github.io/templates/photo-release-form.html
- Cleaning services contract: https://getclausery.github.io/templates/cleaning-services-contract.html
- Nanny contract: https://getclausery.github.io/templates/nanny-contract.html
- Catering contract: https://getclausery.github.io/templates/catering-contract.html
- Change order form: https://getclausery.github.io/templates/change-order-form.html
- Pet sitting agreement: https://getclausery.github.io/templates/pet-sitting-agreement.html
- Coaching agreement: https://getclausery.github.io/templates/coaching-agreement.html

LANDLORDS AND TENANTS
- Rental application: https://getclausery.github.io/templates/rental-application.html
- Rent receipt: https://getclausery.github.io/templates/rent-receipt.html
- Lease renewal letter: https://getclausery.github.io/templates/lease-renewal-letter.html
- Pet addendum: https://getclausery.github.io/templates/pet-addendum.html
- Residential lease agreement: https://getclausery.github.io/templates/residential-lease-agreement.html
- Sublease agreement: https://getclausery.github.io/templates/sublease-agreement.html
- Move-in and move-out checklist: https://getclausery.github.io/templates/move-in-checklist.html
- Late rent notice: https://getclausery.github.io/templates/late-rent-notice.html
- Notice to vacate (tenant): https://getclausery.github.io/templates/notice-to-vacate.html
- Rent increase letter: https://getclausery.github.io/templates/rent-increase-letter.html
- Security deposit return letter: https://getclausery.github.io/templates/security-deposit-return-letter.html
- Roommate agreement: https://getclausery.github.io/templates/roommate-agreement.html
- Lease termination agreement: https://getclausery.github.io/templates/lease-termination-agreement.html
- Room rental agreement: https://getclausery.github.io/templates/room-rental-agreement.html
- Rent payment plan agreement: https://getclausery.github.io/templates/rent-payment-plan-agreement.html
- Landlord reference letter: https://getclausery.github.io/templates/landlord-reference-letter.html

NDAS, LETTERS AND SALES
- Mutual NDA: https://getclausery.github.io/templates/mutual-nda.html
- Non-solicitation agreement: https://getclausery.github.io/templates/non-solicitation-agreement.html
- Liability waiver: https://getclausery.github.io/templates/liability-waiver.html
- Employee NDA: https://getclausery.github.io/templates/employee-nda.html
- Contractor NDA: https://getclausery.github.io/templates/contractor-nda.html
- NDA for selling a business: https://getclausery.github.io/templates/business-sale-nda.html
- Law firm engagement letter: https://getclausery.github.io/templates/engagement-letter.html
- One-way NDA: https://getclausery.github.io/templates/one-way-nda.html
- Cease and desist letter: https://getclausery.github.io/templates/cease-and-desist-letter.html
- Bill of sale: https://getclausery.github.io/templates/bill-of-sale.html
- General release: https://getclausery.github.io/templates/general-release.html
- Hold harmless agreement: https://getclausery.github.io/templates/hold-harmless-agreement.html
- Non-compete agreement: https://getclausery.github.io/templates/non-compete-agreement.html
- Contract termination letter: https://getclausery.github.io/templates/contract-termination-letter.html

HR LETTERS
- Employment agreement: https://getclausery.github.io/templates/employment-agreement.html
- Employee warning letter: https://getclausery.github.io/templates/employee-warning-letter.html
- Promotion letter: https://getclausery.github.io/templates/promotion-letter.html
- Offer letter: https://getclausery.github.io/templates/offer-letter.html
- Employment verification letter: https://getclausery.github.io/templates/employment-verification-letter.html
- Termination letter: https://getclausery.github.io/templates/employment-termination-letter.html
- Reference letter: https://getclausery.github.io/templates/reference-letter.html
- Salary increase letter: https://getclausery.github.io/templates/salary-increase-letter.html
- Internship offer letter: https://getclausery.github.io/templates/internship-offer-letter.html
- Resignation letter: https://getclausery.github.io/templates/resignation-letter.html
- Two weeks notice letter: https://getclausery.github.io/templates/two-weeks-notice-letter.html
- Severance agreement: https://getclausery.github.io/templates/severance-agreement.html
- Job description: https://getclausery.github.io/templates/job-description.html
- Performance improvement plan: https://getclausery.github.io/templates/performance-improvement-plan.html
- Remote work agreement: https://getclausery.github.io/templates/remote-work-agreement.html

All templates, guides and free tools: https://getclausery.github.io/
