Clausery: free Word templates

38 templates, in a folder per category. Each is an ordinary .docx file.

Two ways to use them:
1. Open a file in Word and replace each {tag} with your own details. Sections such as {#has_deposit}...{/has_deposit} are optional: keep the text inside if it applies, and delete it if not. Text inside {^has_deposit}...{/has_deposit} is the opposite: keep it only if the option does not apply.
2. Or open the template's page below and click "Fill it in now". Clausery asks a few questions and builds the finished document in your browser. Nothing is uploaded.

These are general samples, not legal advice. Have them reviewed for your jurisdiction before use.

BUSINESS AGREEMENTS
- Independent contractor agreement: https://getclausery.github.io/templates/independent-contractor-agreement.html
- Statement of work: https://getclausery.github.io/templates/statement-of-work.html
- Consulting agreement: https://getclausery.github.io/templates/consulting-agreement.html
- Service agreement: https://getclausery.github.io/templates/service-agreement.html
- Subcontractor agreement: https://getclausery.github.io/templates/subcontractor-agreement.html
- Memorandum of understanding (MOU): https://getclausery.github.io/templates/memorandum-of-understanding.html
- Letter of intent (business purchase): https://getclausery.github.io/templates/letter-of-intent.html
- Partnership agreement: https://getclausery.github.io/templates/partnership-agreement.html
- Sales commission agreement: https://getclausery.github.io/templates/sales-commission-agreement.html

FREELANCE CONTRACTS
- Web design contract: https://getclausery.github.io/templates/web-design-contract.html
- Graphic design contract: https://getclausery.github.io/templates/graphic-design-contract.html
- Photography contract: https://getclausery.github.io/templates/photography-contract.html
- Social media management contract: https://getclausery.github.io/templates/social-media-management-contract.html
- Freelance writing contract: https://getclausery.github.io/templates/freelance-writing-contract.html
- Video production contract: https://getclausery.github.io/templates/video-production-contract.html
- Virtual assistant agreement: https://getclausery.github.io/templates/virtual-assistant-agreement.html
- Event planning contract: https://getclausery.github.io/templates/event-planning-contract.html
- Personal training agreement: https://getclausery.github.io/templates/personal-training-agreement.html
- Tutoring agreement: https://getclausery.github.io/templates/tutoring-agreement.html
- Retainer agreement: https://getclausery.github.io/templates/retainer-agreement.html
- Photo and model release: https://getclausery.github.io/templates/photo-release-form.html

LOANS AND GETTING PAID
- Payment demand letter: https://getclausery.github.io/templates/payment-demand-letter.html
- Promissory note: https://getclausery.github.io/templates/promissory-note.html
- Payment reminder letter: https://getclausery.github.io/templates/payment-reminder-letter.html
- Loan agreement: https://getclausery.github.io/templates/loan-agreement.html

NDAS, LETTERS AND SALES
- Mutual NDA: https://getclausery.github.io/templates/mutual-nda.html
- Engagement letter: https://getclausery.github.io/templates/engagement-letter.html
- One-way NDA: https://getclausery.github.io/templates/one-way-nda.html
- Cease and desist letter: https://getclausery.github.io/templates/cease-and-desist-letter.html
- Bill of sale: https://getclausery.github.io/templates/bill-of-sale.html
- General release: https://getclausery.github.io/templates/general-release.html

HR LETTERS
- Offer letter: https://getclausery.github.io/templates/offer-letter.html
- Employment verification letter: https://getclausery.github.io/templates/employment-verification-letter.html
- Termination letter: https://getclausery.github.io/templates/employment-termination-letter.html
- Reference letter: https://getclausery.github.io/templates/reference-letter.html
- Salary increase letter: https://getclausery.github.io/templates/salary-increase-letter.html
- Internship offer letter: https://getclausery.github.io/templates/internship-offer-letter.html
- Resignation letter: https://getclausery.github.io/templates/resignation-letter.html

All templates, guides and free tools: https://getclausery.github.io/
