Clausery: free small business document kit

Six ordinary Word templates: quote, statement of work, invoice, payment receipt, purchase order and credit note.

QUICKEST WAY TO MAKE A COMPLETED DOCUMENT
Open the matching resource page below and choose the online questionnaire. Fill in your details, review the amounts and download an editable .docx. No account is required. Document contents are processed on your device.

IF YOU EDIT THE TEMPLATE DIRECTLY IN WORD
These files contain placeholder tags; they are not finished documents.
Replace each {tag} with your details. For {#condition}...{/condition}, keep the enclosed text only if it applies, and remove both markers. For {^condition}...{/condition}, keep the enclosed text only if the condition does not apply. For repeating lists, copy the enclosed row or paragraph for each item and remove the markers. Calculate and check all totals yourself when editing directly in Word. The online questionnaire handles these steps for you.

BEFORE SENDING
Check names, document references, dates, agreed scope, prices, payment details, totals and tax settings. Record payments as received only after they arrive. Keep a copy of the version you send. Download an app backup before clearing browser data or moving to another device.

RESOURCE PAGES
Price quote: https://getclausery.github.io/templates/quote.html
Statement of work: https://getclausery.github.io/templates/statement-of-work.html
Invoice: https://getclausery.github.io/templates/invoice.html
Payment receipt: https://getclausery.github.io/templates/payment-receipt.html
Purchase order: https://getclausery.github.io/templates/purchase-order.html
Credit note: https://getclausery.github.io/templates/credit-note.html

Deposit, hourly and final invoices: https://getclausery.github.io/invoice-templates/
Kit and setup checklist: https://getclausery.github.io/business-document-kit/
Contact: https://getclausery.github.io/contact/

These are general document samples. You are responsible for their content and for the requirements that apply to your business and location.
